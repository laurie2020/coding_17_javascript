let nombre = 8.56

// Arrondir au nombre à l'entier le plus proche

// Arrondir à l'entier vers le haut

// Arrondir à l'entier vers le bas

// Enlever toute la partie décimale

// Afficher un nombre aléatoire entre 0-1

// Afficher un nombre aléatoire entre 0-100

// Afficher un nombre entier aléatoire entre 0-100

// Afficher 8 puissance 2

// Afficher racine carré de 9
// Racine carré
// Racine cubique

// Afficher la valeur absolue de -1

// Afficher la valeur la plus grande parmi -2, 1000, 8, 57

// Afficher la valeur la plus petite parmi -2, 1000, 8, 57
