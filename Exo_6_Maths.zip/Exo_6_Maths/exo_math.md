# Exercice Math

### 1. let nombre = 8.56

### 2.  Arrondir au nombre à l'entier le plus proche


### 3.  Arrondir à l'entier vers le haut


### 4.  Arrondir à l'entier vers le bas


### 5.  Enlever toute la partie décimale


### 6.  Afficher un nombre aléatoire entre 0-1


### 7.  Afficher un nombre aléatoire entre 0-100


### 8.  Afficher un nombre entier aléatoire entre 0-100


### 9.  Afficher 8 puissance 2


### 10.  Afficher racine carré de 9


### 11.  Afficher la valeur absolue de -1


### 12.  Afficher la valeur la plus grande parmi -2, 1000, 8, 57


### 13.  Afficher la valeur la plus petite parmi -2, 1000, 8, 57
